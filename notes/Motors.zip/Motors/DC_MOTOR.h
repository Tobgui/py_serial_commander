#ifndef DC_MOTOR_H
#define DC_MOTOR_H

#include <Arduino.h>

class DC_MOTOR {
public:
    DC_MOTOR(int In1, int In2, int Enable, int EncA, int EncB, float wheel_diameter, int ppr);
    void init();
    void setSpeed(int Speed);
    void forward();
    void forward(int Speed);
    void backward();
    void backward(int Speed);
    void stop();
    void setWheelDiameter(float diameter); // in meters
    int get_pos_feedback_1();
    int get_pos_feedback_2();
    void reset_pos_1();
    void reset_pos_2();
    void update_velocity_1(unsigned long current_time);
    void update_velocity_2(unsigned long current_time);
    float get_velocity_1();
    float get_velocity_2();

private:
    static int motor_num;
    static DC_MOTOR* motor1_ptr;
    static DC_MOTOR* motor2_ptr;
    int in1, in2, EN, encA, encB;
    int speed;
    volatile long pos_1, last_pos_1, last_time_1;
    volatile long pos_2, last_pos_2, last_time_2;
    volatile float velocity_1;
    volatile float velocity_2;
    float wheel_diameter; // in meters
    int pulses_per_revolution; // PPR value

    static void encoder_callback1();
    static void encoder_callback2();
    void handle_encoder_1();
    void handle_encoder_2();
};

#endif
